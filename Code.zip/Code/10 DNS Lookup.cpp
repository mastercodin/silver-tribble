#include <iostream>
#include <string>
#include <cstring>
#include <netdb.h>       // For gethostbyname, hostent
#include <arpa/inet.h>   // For inet_ntoa
#include <sys/socket.h>  // For socket types
#include <limits>        // For numeric_limits

using namespace std;

/**
 * @brief Displays host information (Canonical Name and first IP Address) 
 * using the POSIX gethostbyname function.
 * @param input The host name or IP address string to look up.
 */
void displayHostInfo(const string& input) {
    // gethostbyname is a legacy POSIX function but is sufficient for this simple lookup.
    // It attempts to resolve the input (whether hostname or IP string) to host information.
    struct hostent *host = gethostbyname(input.c_str());

    if (host == nullptr) {
        // If gethostbyname fails, it returns nullptr.
        cerr << "Could not find " << input << ". ";
        // We can use hstrerror(h_errno) for more detailed error messages if needed,
        // but the requested output only requires the user-friendly message.
        cerr << "Please check the input and try again." << endl;
        return;
    }

    // host->h_name contains the canonical host name.
    // host->h_addr_list is a null-terminated array of IP addresses for the host.
    // We convert the first address (network byte order) to a readable string using inet_ntoa.
    char *ip_address_str = inet_ntoa(*(struct in_addr *)host->h_addr_list[0]);
    
    cout << "\n--- Lookup Results ---\n";
    cout << "Host Name: " << host->h_name << endl;
    cout << "IP Address: " << ip_address_str << endl;

    // Simulating the Java 'address.toString()' output format
    cout << "Host Info: " << host->h_name << "/" << ip_address_str << endl;
}

int main() {
    int choice;
    string input;

    cout << "Choose an option:\n";
    cout << "1. Enter Host Name\n";
    cout << "2. Enter IP Address\n";
    cout << "Choice: ";
    
    // Read the user's choice (integer)
    if (!(cin >> choice)) {
        cerr << "Invalid choice format. Exiting...\n";
        return 1;
    }
    
    // Clear the input buffer (crucial after reading an integer, before reading a string)
    cin.ignore(numeric_limits<streamsize>::max(), '\n');

    if (choice == 1) {
        cout << "Enter Host Name: ";
        getline(cin, input);
    } else if (choice == 2) {
        cout << "Enter IP Address: ";
        getline(cin, input);
    } else {
        cout << "Invalid choice. Exiting..." << endl;
        return 0;
    }

    if (!input.empty()) {
        displayHostInfo(input);
    } else {
        cerr << "Input cannot be empty. Exiting...\n";
    }

    return 0;
}

