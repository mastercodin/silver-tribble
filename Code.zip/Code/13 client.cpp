#include <iostream>
#include <cstring>
#include <arpa/inet.h>

#define PORT 8080
#define SERVER_IP "REMOTE_IP"  // Replace with your server's IP

int main() {
    int sockfd;
    struct sockaddr_in server_addr;
    const char *command = "sudo apt-get install -y isc-dhcp-server";  // Command to install DHCP server

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        std::cerr << "Socket creation failed." << std::endl;
        return 1;
    }

    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    inet_pton(AF_INET, SERVER_IP, &server_addr.sin_addr);

    sendto(sockfd, command, strlen(command), MSG_CONFIRM, (const struct sockaddr *)&server_addr, sizeof(server_addr));

    char buffer[1024];
    int n = recvfrom(sockfd, buffer, sizeof(buffer), MSG_WAITALL, nullptr, nullptr);
    buffer[n] = '\0';
    std::cout << "Server response: " << buffer << std::endl;

    close(sockfd);
    return 0;
}

