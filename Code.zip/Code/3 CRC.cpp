#include <iostream>
#include <string>
using namespace std;

// Function to perform XOR operation on two binary strings
string xor1(const string& a, const string& b) {
    string result = "";
    for (size_t i = 0; i < b.length(); ++i) {
        result += (a[i] == b[i]) ? '0' : '1';
    }
    return result;
}

// Function to perform modulo-2 division (CRC calculation)
string mod2div(const string& dividend, const string& divisor) {
    int pick = divisor.length();
    string tmp = dividend.substr(0, pick);
    int n = dividend.length();

    while (pick < n) {
        if (tmp[0] == '1') {
            tmp = xor1(divisor, tmp) + dividend[pick];
        } else {
            tmp = xor1(string(pick, '0'), tmp) + dividend[pick];
        }
        ++pick;
    }

    if (tmp[0] == '1') {
        tmp = xor1(divisor, tmp);
    } else {
        tmp = xor1(string(pick, '0'), tmp);
    }

    return tmp;
}

// Function to flip the last n bits of a binary string
string flip_last_n(string s, int n) {
    for (int i = s.length() - n; i < s.length(); ++i) {
        s[i] = (s[i] == '0') ? '1' : '0';
    }
    return s;
}

int main() {
    string data, generator;
    cout << "Enter data bits: ";
    cin >> data;
    cout << "Enter generator polynomial (binary): ";
    cin >> generator;

    int n = generator.length() - 1;
    string appended_data = data + string(n, '0');
    string remainder = mod2div(appended_data, generator);
    string codeword = data + remainder;

    cout << "CRC codeword (sent): " << codeword << endl;
    cout << "Remainder (CRC bits): " << remainder << endl;

    string received = flip_last_n(codeword, n);
    cout << "Received codeword (Last " << n << " bits flipped): " << received << endl;

    string rec_remainder = mod2div(received, generator);
    bool error = false;
    for (char c : rec_remainder) {
        if (c != '0') {
            error = true;
            break;
        }
    }

    if (error) {
        cout << "Error detected in received codeword." << endl;
    } else {
        cout << "No error detected in received codeword." << endl;
    }

    return 0;
}
