#include <iostream>
#include <vector>
#include <cmath>
using namespace std;

// Function to calculate parity for a given position
int check_parity(int n, int i, vector<int> code) {
    int count = 0;
    for (int j = i; j <= n; j += 2 * i) {
        for (int k = j; k < j + i && k <= n; k++) {
            if (code[k] == 1)
                count++;
        }
    }
    return count % 2; // Even parity
}

// Function to generate Hamming code with error detection/correction
void generateHammingCode(vector<int> data, int size) {
    int r = 0;
    while (pow(2, r) < size + r + 1) r++; // Calculate required parity bits
    int n = size + r; // Total code length
    
    vector<int> code(n + 1, 0); // 1-based indexing for simplicity
    int j = 0;
    
    // Populate data bits into code array
    for (int i = 1; i <= n; i++) {
        if (pow(2, (int)log2(i)) == i) {
            code[i] = 0; // Initialize parity positions
        } else {
            code[i] = data[j++]; // Place data bits
        }
    }
    
    // Calculate parity bits
    for (int i = 0; i < r; i++) {
        int p = pow(2, i);
        code[p] = check_parity(n, p, code);
    }
    
    // Display generated Hamming code
    cout << "Generated Hamming Code: ";
    for (int i = n; i >= 1; i--) cout << code[i];
    cout << endl;
    
    // Simulate error by flipping last r bits (parity bits)
    for (int i = n - r + 1; i <= n; i++) {
        code[i] ^= 1; // Flip the bit
    }
    
    cout << "Received Code (with simulated error): ";
    for (int i = n; i >= 1; i--) cout << code[i];
    cout << endl;
    
    // Error detection and correction
    int error_pos = 0;
    for (int i = 0; i < r; i++) {
        int p = pow(2, i);
        if (check_parity(n, p, code) != 0)
            error_pos += p; // Sum error positions
    }
    
    if (error_pos == 0) {
        cout << "No error detected." << endl;
    } else {
        cout << "Error detected at position: " << error_pos << endl;
        code[error_pos] ^= 1; // Correct the error
        cout << "Corrected Code: ";
        for (int i = n; i >= 1; i--) cout << code[i];
        cout << endl;
    }
}

int main() {
    int size;
    cout << "Enter number of data bits: ";
    cin >> size;
    
    vector<int> data(size);
    cout << "Enter data bits (MSB first): ";
    for (int i = 0; i < size; i++)
        cin >> data[i];
    
    generateHammingCode(data, size);
    return 0;
}
