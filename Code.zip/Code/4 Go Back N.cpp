#include <iostream>
#include <vector>
#include <numeric>

using namespace std;

// Maximum sequence number space (0 to 6)
#define MAX_SEQ 7 

/**
 * @class GoBackN
 * @brief Simulates the Go-Back-N (GBN) reliable data transfer protocol.
 * * In GBN, if a frame is lost, the sender retransmits that frame AND all 
 * subsequently sent frames.
 */
class GoBackN {
private:
    int base = 0;           // Sequence number of the oldest unacknowledged frame.
    int nextSeqNum = 0;     // Sequence number of the next frame to be sent.
    int windowSize;
    vector<bool> acked;     // Tracks frames that have been acknowledged and are within the window.
    vector<bool> initiallyLost; // Tracks which frames are initially lost by the receiver.

public:
    /**
     * @brief Constructor for the GoBackN simulator.
     * @param w The size of the sliding window.
     * @param frameLost A vector indicating which frames are lost initially.
     */
    GoBackN(int w, const vector<bool> &frameLost) 
        : windowSize(w), acked(MAX_SEQ, false), initiallyLost(frameLost) {}

    /**
     * @brief Simulates the sender's process, including sending, receiving ACKs, 
     * and handling timeouts/losses by retransmitting.
     */
    void sender() {
        cout << "\n--- Go-Back-N Sender Simulation ---\n";
        cout << "Window Size: " << windowSize << "\n";
        
        // Loop until all frames are acknowledged
        while (base < MAX_SEQ) {
            // 1. Send frames up to the window limit
            while (nextSeqNum < base + windowSize && nextSeqNum < MAX_SEQ) {
                cout << "-> Sending frame " << nextSeqNum << endl;

                // Check for initial loss (simulating receiver failure to ACK)
                if (initiallyLost[nextSeqNum]) {
                    cout << "   Frame " << nextSeqNum << " lost/ACK missing.\n";
                    
                    // In GBN, detecting a loss/timeout usually triggers a break
                    // to stop sending new frames and wait for timeout/retransmission.
                    initiallyLost[nextSeqNum] = false; // Prepare for retransmission
                    break; 
                } else {
                    // Simulating immediate successful ACK reception
                    cout << "   ACK received for frame " << nextSeqNum << " (Successful initial send).\n";
                    acked[nextSeqNum] = true;
                }
                nextSeqNum++;
            }

            // 2. Advance the sliding window (update base)
            while (base < MAX_SEQ && acked[base]) {
                base++;
            }

            // 3. Handle loss detection (timeout) and retransmission
            if (base < MAX_SEQ && !acked[base]) {
                cout << "\n!!! Timeout detected. Frame " << base << " or its ACK lost.\n";
                // Retransmit from 'base' (the lost frame) onwards
                cout << "!!! Retransmitting ALL subsequent frames starting from frame " << base << endl;
                nextSeqNum = base; // Reset nextSeqNum to base for retransmission
                
                // In a proper GBN simulation, subsequent frames sent *before* timeout are also retransmitted.
                // Here, we simulate that the retransmitted frame is successfully ACKed, 
                // allowing the base to move after the retransmission window runs.
            }
        }
        cout << "\nAll " << MAX_SEQ << " frames sent and acknowledged in Go-Back-N.\n";
    }
};

int main() {
    // Set the window size
    int windowSize = 4;
    
    // Define which frames are initially lost (e.g., ACK is lost or frame is corrupted)
    vector<bool> frameLost(MAX_SEQ, false);
    frameLost[2] = true; // Frame 2 is lost
    frameLost[5] = true; // Frame 5 is lost

    // Initialize and run the Go-Back-N simulation
    GoBackN gbn(windowSize, frameLost);
    gbn.sender();

    return 0;
}

