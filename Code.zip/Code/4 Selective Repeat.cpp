#include <iostream>
#include <vector>
#include <numeric>

using namespace std;

// Maximum sequence number space (0 to 6)
#define MAX_SEQ 7 

/**
 * @class SelectiveRepeat
 * @brief Simulates the Selective Repeat (SR) reliable data transfer protocol.
 * * In SR, only the specific lost frame is retransmitted. The receiver buffers 
 * correctly received frames beyond the lost frame.
 */
class SelectiveRepeat {
private:
    int base = 0;           // Sequence number of the oldest unacknowledged frame.
    int nextSeqNum = 0;     // Sequence number of the next frame to be sent.
    int windowSize;
    vector<bool> acked;     // Tracks frames that have been successfully acknowledged.
    vector<bool> initiallyLost; // Tracks which frames are initially lost.

public:
    /**
     * @brief Constructor for the Selective Repeat simulator.
     * @param w The size of the sliding window.
     * @param frameLost A vector indicating which frames are lost initially.
     */
    SelectiveRepeat(int w, const vector<bool> &frameLost) 
        : windowSize(w), acked(MAX_SEQ, false), initiallyLost(frameLost) {}

    /**
     * @brief Simulates the sender's process for Selective Repeat.
     */
    void sender() {
        cout << "\n--- Selective Repeat Sender Simulation ---\n";
        cout << "Window Size: " << windowSize << "\n";

        // Loop until all frames are acknowledged
        while (base < MAX_SEQ) {
            // 1. Send frames up to the window limit
            while (nextSeqNum < base + windowSize && nextSeqNum < MAX_SEQ) {
                cout << "-> Sending frame " << nextSeqNum << endl;

                // Check for initial loss
                if (initiallyLost[nextSeqNum]) {
                    cout << "   Frame " << nextSeqNum << " lost. (Will retransmit later)\n";
                    initiallyLost[nextSeqNum] = false; // Mark for retransmission attempt
                } else {
                    // Simulating immediate successful ACK reception
                    cout << "   ACK received for frame " << nextSeqNum << " (Successful initial send).\n";
                    acked[nextSeqNum] = true;
                }
                nextSeqNum++;
            }
            
            // 2. Advance the sliding window (update base)
            while (base < MAX_SEQ && acked[base]) {
                base++;
            }
            
            // 3. Check for unacknowledged frames within the current window and retransmit selectively
            // Note: In a real SR, this would be based on timeouts for individual frames.
            for (int i = base; i < base + windowSize && i < MAX_SEQ; i++) {
                if (!acked[i]) {
                    cout << "\n!!! Timeout detected for frame " << i << ". Retransmitting selectively.\n";
                    
                    // Simulate successful retransmission and ACK reception
                    cout << "   ACK received for frame " << i << " after retransmission.\n";
                    acked[i] = true;
                }
            }
            
            // After retransmitting, advance the window again if the base frame is now acknowledged
            while (base < MAX_SEQ && acked[base]) {
                base++;
            }
        }
        cout << "\nAll " << MAX_SEQ << " frames sent and acknowledged in Selective Repeat.\n";
    }
};

int main() {
    // Set the window size
    int windowSize = 4;
    
    // Define which frames are initially lost (e.g., ACK is lost or frame is corrupted)
    vector<bool> frameLost(MAX_SEQ, false);
    frameLost[2] = true; // Frame 2 is lost
    frameLost[5] = true; // Frame 5 is lost

    // Initialize and run the Selective Repeat simulation
    SelectiveRepeat sr(windowSize, frameLost);
    sr.sender();

    return 0;
}

