#include <iostream>
#include <string>
#include <vector>
#include <cmath>
#include <sstream>
#include <algorithm>

using namespace std;

// Define a safe value for the maximum number of octets in an IP address
#define OCTETS 4

/**
 * @brief Prints an IP address or mask in dotted-decimal notation.
 * @param ip A vector of 4 integers representing the octets.
 */
void printDottedDecimal(const vector<int>& ip) {
    if (ip.size() == OCTETS) {
        cout << ip[0] << "." << ip[1] << "." << ip[2] << "." << ip[3];
    }
}

/**
 * @brief Calculates the subnet mask given the total number of network bits (CIDR prefix).
 * @param newNetworkBits The final CIDR length (e.g., 27 for /27).
 * @return A vector of 4 integers representing the new subnet mask.
 */
vector<int> calculateSubnetMask(int newNetworkBits) {
    vector<int> mask(OCTETS, 0);
    int remainingBits = newNetworkBits;

    for (int i = 0; i < OCTETS; ++i) {
        if (remainingBits >= 8) {
            mask[i] = 255; // Full octet of 1s
            remainingBits -= 8;
        } else if (remainingBits > 0) {
            // Calculate the mask value for the partial octet (e.g., 3 bits = 224)
            int maskValue = 0;
            for (int j = 0; j < remainingBits; ++j) {
                maskValue += pow(2, 7 - j);
            }
            mask[i] = maskValue;
            remainingBits = 0;
        } else {
            mask[i] = 0; // Octet is all 0s
        }
    }
    return mask;
}

/**
 * @brief Main function for the Subnet Calculator.
 */
int main() {
    string ipAddressStr;
    cout << "Enter an IP Address (e.g., 192.168.1.0): ";
    // Use getline to allow flexibility, though cin >> ipAddressStr is used in original
    cin >> ipAddressStr; 

    vector<int> ip(OCTETS);
    char dot;
    stringstream ss(ipAddressStr);
    
    // Attempt to parse the IP address
    if (!(ss >> ip[0] >> dot >> ip[1] >> dot >> ip[2] >> dot >> ip[3]) || ss.peek() != EOF) {
        cout << "Error: Invalid IP Address format entered." << endl;
        return 1;
    }
    
    // Input validation (each octet must be between 0 and 255)
    for (int octet : ip) {
        if (octet < 0 || octet > 255) {
            cout << "Error: IP octet out of range (0-255)." << endl;
            return 1;
        }
    }

    char ipClass;
    vector<int> defaultMask(OCTETS);
    int networkBits; // Default network bits (e.g., 8, 16, 24)
    
    // 1. Determine IP Class and Default Mask
    if (ip[0] >= 1 && ip[0] <= 126) {
        ipClass = 'A';
        defaultMask = {255, 0, 0, 0};
        networkBits = 8;
    } else if (ip[0] >= 128 && ip[0] <= 191) {
        ipClass = 'B';
        defaultMask = {255, 255, 0, 0};
        networkBits = 16;
    } else if (ip[0] >= 192 && ip[0] <= 223) {
        ipClass = 'C';
        defaultMask = {255, 255, 255, 0};
        networkBits = 24;
    } else {
        cout << "IP Address is Class D (Multicast), E (Reserved), or invalid. This program supports Class A, B, and C." << endl;
        return 1;
    }

    cout << "\nIP Address Class: " << ipClass << endl;
    cout << "Default Subnet Mask: ";
    printDottedDecimal(defaultMask);
    cout << " (/" << networkBits << ")" << endl;

    // 2. Input Subnet Requirement and Calculate Bits
    int numSubnets;
    cout << "\nEnter the number of subnets required: ";
    cin >> numSubnets;
    
    if (numSubnets < 2) {
        cout << "Error: You must request at least 2 subnets to perform subnetting." << endl;
        return 1;
    }

    // Calculate borrowed bits (ceiling of log2(numSubnets))
    int borrowedBits = ceil(log2(numSubnets));
    int newNetworkBits = networkBits + borrowedBits;
    int hostBits = 32 - newNetworkBits;
    
    // Check if the required number of subnets is possible
    if (hostBits < 2) { // Need at least 2 host bits for usable addresses (network and broadcast)
        cout << "Error: Not enough host bits available (" << 32 - networkBits 
             << ") to create " << numSubnets << " subnets.\n";
        return 1;
    }

    // 3. Calculate New Subnet Mask
    vector<int> newMask = calculateSubnetMask(newNetworkBits);
    
    // Determine the octet where subnetting occurs (0-indexed)
    // Class A (8 bits) -> Octet 1
    // Class B (16 bits) -> Octet 2
    // Class C (24 bits) -> Octet 3
    int subnetOctetIndex = networkBits / 8; 

    // Calculate the block size (increment) in the subnetting octet
    // This is the interval between network IDs
    int blockSize = 256 - newMask[subnetOctetIndex]; 

    // 4. Output Subnetting Details
    cout << "\n--- Subnetting Details ---" << endl;
    cout << "New Subnet Mask: ";
    printDottedDecimal(newMask);
    cout << " (/" << newNetworkBits << ")" << endl;
    cout << "Bits Borrowed (s): " << borrowedBits << endl;
    cout << "Total Subnets (2^s): " << pow(2, borrowedBits) << endl;
    cout << "Total Hosts per Subnet (2^h - 2): " << (pow(2, hostBits) - 2) << endl;

    // 5. Calculate and Output Subnet Ranges
    cout << "\n--- Subnet Ranges ---" << endl;
    
    for (int i = 0; i < pow(2, borrowedBits); ++i) {
        vector<int> networkId = ip;
        vector<int> broadcastId = ip;

        // Reset the octets after the subnetting octet to 0 for Network ID
        // The last octet of the block size is set by i * blockSize
        for (int j = subnetOctetIndex + 1; j < OCTETS; ++j) {
            networkId[j] = 0;
            broadcastId[j] = 255;
        }

        // Set the value in the subnetting octet
        networkId[subnetOctetIndex] = i * blockSize;
        broadcastId[subnetOctetIndex] = networkId[subnetOctetIndex] + blockSize - 1;
        
        // Correct broadcast for the last octet of the block size
        // If the block size is 256, it wraps around (only applies to A/B class in a larger scope, 
        // but the core logic is now simpler and index-based.)

        // For C-class, all action is in octet 3.
        if (ipClass == 'C') {
            // networkId[0], networkId[1], networkId[2] remain from the input IP for Class C
            // networkId[3] is already set to i * blockSize
            broadcastId[3] = networkId[3] + blockSize - 1;
            
            // Fix the Network ID octets 0, 1, 2 to be from the input IP
            networkId[0] = ip[0]; networkId[1] = ip[1]; networkId[2] = ip[2];
            broadcastId[0] = ip[0]; broadcastId[1] = ip[1]; broadcastId[2] = ip[2];
            
        } else if (ipClass == 'B') {
            // Subnetting occurs in octet 2 (index 2).
            // networkId[0], networkId[1] remain from the input IP for Class B
            networkId[0] = ip[0]; networkId[1] = ip[1];
            broadcastId[0] = ip[0]; broadcastId[1] = ip[1];

            // If block size is 256, it means we borrowed 0 bits in this octet, which is impossible 
            // since we already checked hostBits >= 2. The block size here must be in octet 2.
            
            // networkId[2] is set to i * blockSize
            // broadcastId[2] is set to networkId[2] + blockSize - 1
            // networkId[3] is 0, broadcastId[3] is 255 (already set in the loop above)

        } else if (ipClass == 'A') {
            // Subnetting occurs in octet 1 (index 1).
            // networkId[0] remains from the input IP for Class A
            networkId[0] = ip[0];
            broadcastId[0] = ip[0];

            // networkId[1] is set to i * blockSize
            // broadcastId[1] is set to networkId[1] + blockSize - 1
            // networkId[2] is 0, networkId[3] is 0 (already set)
            // broadcastId[2] is 255, broadcastId[3] is 255 (already set)
        }


        // Calculate First and Last Host addresses
        vector<int> firstHost = networkId;
        vector<int> lastHost = broadcastId;

        // First host is Network ID + 1 (in the last octet)
        firstHost[OCTETS - 1]++;
        
        // Last host is Broadcast ID - 1 (in the last octet)
        lastHost[OCTETS - 1]--;
        
        // Handle wrap-around for first host if all host bits are in the last octet
        // If the calculated network address is 192.168.1.255, it's not a network ID, but a broadcast.
        // The previous logic guarantees that networkId[3] is always the start of a block, so +1 is correct.

        cout << "\nSubnet " << i + 1 << ":" << endl;
        cout << " Network Address: ";
        printDottedDecimal(networkId);
        cout << endl;
        
        cout << " Host Range: ";
        printDottedDecimal(firstHost);
        cout << " - ";
        printDottedDecimal(lastHost);
        cout << endl;
        
        cout << " Broadcast Address: ";
        printDottedDecimal(broadcastId);
        cout << endl;
    }

    return 0; 
}

