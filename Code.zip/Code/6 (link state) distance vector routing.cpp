#include <iostream>
#include <vector>
#include <algorithm> // For std::min

using namespace std;

// Define a large constant to represent infinite cost (no direct link)
#define INF 99999

/**
 * @brief Main function to implement the Floyd-Warshall algorithm for routing tables.
 */
int main() {
    int n;
    cout << "Enter number of routers: ";
    cin >> n;

    // 1. Initialize Cost Matrix (Adjacency Matrix)
    // Use dynamic array sizing or vector<vector<int>> for modern C++.
    // Using VLAs (variable length arrays) as in the original code for compatibility:
    int cost[n][n];

    // Initialize all costs: 0 for self-loop, INF for others
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cost[i][j] = (i == j) ? 0 : INF;
        }
    }

    // 2. Read Direct Link Costs from User
    cout << "\n--- Enter Direct Link Costs ---\n";
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            int c;
            // Improved prompt for clarity
            cout << "Enter cost between router " << i + 1 << " and router " << j + 1
                 << " (-1 for no link): ";
            cin >> c;

            if (c != -1) {
                // Update both directions since the graph is assumed undirected
                cost[i][j] = cost[j][i] = c;
            }
        }
    }

    // 3. Initialize Distance Matrix
    // The dist matrix starts as a copy of the cost matrix.
    int dist[n][n];
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            dist[i][j] = cost[i][j];
        }
    }

    // 4. Floyd-Warshall Algorithm Implementation
    // k is the intermediate router
    for (int k = 0; k < n; k++) {
        // i is the source router
        for (int i = 0; i < n; i++) {
            // j is the destination router
            for (int j = 0; j < n; j++) {
                // Check if the path through k is shorter than the current path
                if (dist[i][k] != INF && dist[k][j] != INF) {
                    dist[i][j] = min(dist[i][j], dist[i][k] + dist[k][j]);
                }
            }
        }
    }

    // 5. Output Final Routing Table
    cout << "\n--- Final Routing Table (Shortest Paths) ---\n";
    for (int i = 0; i < n; i++) {
        cout << "Router " << i + 1 << ": ";
        for (int j = 0; j < n; j++) {
            if (dist[i][j] == INF || dist[i][j] < 0) { // Check for INF and negative cycles (though not fully handled here)
                cout << "INF ";
            } else {
                cout << dist[i][j] << " ";
            }
        }
        cout << "\n"; // Newline for clean separation of router rows
    }
    
    return 0;
}

