#include <iostream>
#include <cstring>
#include <unistd.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>

using namespace std;

int main()
{
    // 1. Create socket
    int s = socket(AF_INET, SOCK_STREAM, 0);
    if (s < 0) {
        cerr << "Error: Could not create socket.\n";
        return 1;
    }

    // 2. Prepare server address structure
    sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(8082); // Server port for calculator
    addr.sin_addr.s_addr = INADDR_ANY;

    // 3. Connect to the server
    if (connect(s, (sockaddr*)&addr, sizeof(addr)) < 0) {
        cerr << "Error: Connection failed.\n";
        close(s);
        return 1;
    }
    cout << "Connected to server.\n";

    // 4. Expression to send
    const char* expr = "15 * 3";
    cout << "Sending expression: " << expr << endl;
    send(s, expr, strlen(expr), 0);

    // 5. Receive result from server
    char buffer[1024] = {0};
    ssize_t n = recv(s, buffer, sizeof(buffer) - 1, 0);

    if (n > 0) {
        buffer[n] = '\0';
        cout << "Received from server: " << buffer << endl;
    } else if (n == 0) {
        cout << "Server closed the connection.\n";
    } else {
        cerr << "Error receiving data.\n";
    }
    
    // 6. Close socket
    close(s);
    return 0;
}

