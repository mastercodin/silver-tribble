#include <iostream>
#include <cstring>
#include <cstdio> // Required for sscanf and sprintf
#include <unistd.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>

using namespace std;

int main()
{
    // 1. Create socket
    int s = socket(AF_INET, SOCK_STREAM, 0);
    if (s < 0) {
        cerr << "Error: Could not create socket.\n";
        return 1;
    }

    // 2. Prepare server address structure
    sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(8082); // Port to listen on
    addr.sin_addr.s_addr = INADDR_ANY;

    // 3. Bind
    if (bind(s, (sockaddr*)&addr, sizeof(addr)) < 0) {
        cerr << "Error: Binding failed.\n";
        close(s);
        return 1;
    }

    // 4. Listen
    if (listen(s, 5) < 0) {
        cerr << "Error: Listen failed.\n";
        close(s);
        return 1;
    }
    cout << "Calculator Server listening on port 8082...\n";

    // 5. Accept connection
    int client = accept(s, nullptr, nullptr);
    if (client < 0) {
        cerr << "Error: Accept failed.\n";
        close(s);
        return 1;
    }
    cout << "Client connected.\n";

    // 6. Receive expression
    char buffer[1024];
    ssize_t n = recv(client, buffer, sizeof(buffer) - 1, 0);

    if (n > 0) {
        buffer[n] = '\0';
        cout << "Received expression: " << buffer << endl;
        
        // 7. Parse and calculate
        int a = 0, b = 0;
        char op = ' ';
        // Expecting format: "15 * 3"
        if (sscanf(buffer, "%d %c %d", &a, &op, &b) == 3) {
            int result = 0;
            string status = "OK";
            
            if (op == '+') result = a + b;
            else if (op == '-') result = a - b;
            else if (op == '*') result = a * b;
            else if (op == '/') {
                if (b != 0) {
                    result = a / b;
                } else {
                    result = 0; // Avoid division by zero
                    status = "Error: Division by zero";
                }
            } else {
                status = "Error: Invalid operator";
            }
            
            if (status == "OK") {
                cout << "Calculated result: " << result << endl;
                sprintf(buffer, "Result = %d", result);
            } else {
                // Send the error message back
                strncpy(buffer, status.c_str(), sizeof(buffer) - 1);
                buffer[sizeof(buffer) - 1] = '\0';
                cerr << status << endl;
            }
            
            // 8. Send result back to client
            send(client, buffer, strlen(buffer), 0);
            
        } else {
            // Handle parsing error
            const char* err_msg = "Error: Invalid expression format.";
            cerr << err_msg << endl;
            send(client, err_msg, strlen(err_msg), 0);
        }
    } else if (n < 0) {
        cerr << "Error receiving data.\n";
    }

    // 9. Close connections
    close(client);
    close(s);
    return 0;
}

