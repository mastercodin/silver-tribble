#include <iostream>
#include <cstring>
#include <unistd.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>

using namespace std;

int main()
{
    // 1. Create socket
    int s = socket(AF_INET, SOCK_STREAM, 0);
    if (s < 0) {
        cerr << "Error: Could not create socket.\n";
        return 1;
    }

    // 2. Prepare server address structure
    sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(8081); // Server port for file transfer
    addr.sin_addr.s_addr = INADDR_ANY; 

    // 3. Connect to the server
    if (connect(s, (sockaddr*)&addr, sizeof(addr)) < 0) {
        cerr << "Error: Connection failed.\n";
        close(s);
        return 1;
    }
    cout << "Connected to server.\n";

    // 4. Content to send (simulating file content)
    const char* file_content = "This is a file content\nLine 2 of file\nLine 3 of file\n";
    
    // 5. Send the content
    cout << "Client sending file content:\n---\n" << file_content << "---" << endl;
    send(s, file_content, strlen(file_content), 0);

    // 6. Close the socket
    close(s);
    return 0;
}

