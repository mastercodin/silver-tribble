#include <iostream>
#include <cstring>
#include <unistd.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>

using namespace std;

int main()
{
    // 1. Create socket
    int s = socket(AF_INET, SOCK_STREAM, 0);
    if (s < 0) {
        cerr << "Error: Could not create socket.\n";
        return 1;
    }

    // 2. Prepare server address structure
    sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(8081); // Port to listen on
    addr.sin_addr.s_addr = INADDR_ANY; 

    // 3. Bind
    if (bind(s, (sockaddr*)&addr, sizeof(addr)) < 0) {
        cerr << "Error: Binding failed.\n";
        close(s);
        return 1;
    }

    // 4. Listen
    if (listen(s, 5) < 0) {
        cerr << "Error: Listen failed.\n";
        close(s);
        return 1;
    }
    cout << "Server listening on port 8081 for file content...\n";

    // 5. Accept connection
    int client = accept(s, nullptr, nullptr);
    if (client < 0) {
        cerr << "Error: Accept failed.\n";
        close(s);
        return 1;
    }
    cout << "Client connected. Receiving data...\n";

    // 6. Receive file content
    char buffer[1024];
    ssize_t n = recv(client, buffer, sizeof(buffer) - 1, 0);
    
    if (n > 0) {
        buffer[n] = '\0'; // Null-terminate
        cout << "Server received file content:\n---\n" << buffer << "---" << endl;
    } else if (n == 0) {
        cout << "Client disconnected.\n";
    } else {
        cerr << "Error receiving data.\n";
    }

    // 7. Close connections
    close(client);
    close(s);
    return 0;
}

