#include <iostream>
#include <cstring>
#include <unistd.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>

using namespace std;

int main()
{
    // 1. Create socket
    int s = socket(AF_INET, SOCK_STREAM, 0);
    if (s < 0) {
        cerr << "Error: Could not create socket.\n";
        return 1;
    }

    // 2. Prepare server address structure
    sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(8080); // Server port
    addr.sin_addr.s_addr = INADDR_ANY; // Connect to local machine (localhost)

    // 3. Connect to the server
    if (connect(s, (sockaddr*)&addr, sizeof(addr)) < 0) {
        cerr << "Error: Connection failed.\n";
        close(s);
        return 1;
    }

    // 4. Send message to server
    const char* msg = "Hello from client";
    cout << "Sending message to server: \"" << msg << "\"\n";
    send(s, msg, strlen(msg), 0);

    // 5. Receive response from server
    char buffer[1024] = {0};
    ssize_t bytes_received = recv(s, buffer, sizeof(buffer) - 1, 0);
    
    if (bytes_received > 0) {
        buffer[bytes_received] = '\0'; // Null-terminate the received data
        cout << "Message from server: " << buffer << endl;
    } else if (bytes_received == 0) {
        cout << "Server closed the connection.\n";
    } else {
        cerr << "Error receiving message.\n";
    }

    // 6. Close the socket
    close(s);
    return 0;
}

