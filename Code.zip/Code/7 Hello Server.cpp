#include <iostream>
#include <cstring>
#include <unistd.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>

using namespace std;

int main()
{
    // 1. Create socket
    int s = socket(AF_INET, SOCK_STREAM, 0);
    if (s < 0) {
        cerr << "Error: Could not create socket.\n";
        return 1;
    }

    // 2. Prepare server address structure
    sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(8080); // Port to listen on
    addr.sin_addr.s_addr = INADDR_ANY; // Listen on all interfaces

    // 3. Bind socket to the address and port
    if (bind(s, (sockaddr*)&addr, sizeof(addr)) < 0) {
        cerr << "Error: Binding failed.\n";
        close(s);
        return 1;
    }

    // 4. Listen for incoming connections
    if (listen(s, 5) < 0) { // Max 5 pending connections
        cerr << "Error: Listen failed.\n";
        close(s);
        return 1;
    }
    cout << "Server listening on port 8080...\n";

    // 5. Accept a client connection
    int client = accept(s, nullptr, nullptr);
    if (client < 0) {
        cerr << "Error: Accept failed.\n";
        close(s);
        return 1;
    }
    cout << "Client connected.\n";

    // 6. Receive message from client
    char buffer[1024] = {0};
    ssize_t bytes_received = recv(client, buffer, sizeof(buffer) - 1, 0);

    if (bytes_received > 0) {
        buffer[bytes_received] = '\0'; // Null-terminate the received data
        cout << "Message from client: " << buffer << endl;
    } else if (bytes_received == 0) {
        cout << "Client closed the connection.\n";
    } else {
        cerr << "Error receiving message.\n";
    }

    // 7. Send response back to client
    const char* msg = "Hello from server";
    cout << "Sending response: \"" << msg << "\"\n";
    send(client, msg, strlen(msg), 0);

    // 8. Close connections
    close(client);
    close(s);
    return 0;
}

