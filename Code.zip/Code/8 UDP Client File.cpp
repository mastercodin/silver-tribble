#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string>

using namespace std;

// Define the port and buffer size
#define PORT 8080
#define BUFFER_SIZE 1024

/**
 * @brief UDP Client program to send a file to a server.
 * @param argc Must be 3 (program name, server IP, file to send).
 * @param argv Command line arguments.
 */
int main(int argc, char *argv[]) {
    int sockfd;
    struct sockaddr_in servaddr;
    FILE *fp = nullptr;
    char buffer[BUFFER_SIZE];
    
    // 1. Command line argument check
    if (argc != 3) {
        std::cerr << "Usage: " << argv[0] << " <server_ip> <file_to_send>" << std::endl;
        return 1;
    }
    
    const char *server_ip = argv[1];
    const char *filename = argv[2];

    // 2. Create socket file descriptor
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        perror("socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Zero out server address structure
    memset(&servaddr, 0, sizeof(servaddr));
    
    // Fill server information
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(PORT);

    // Convert IP address from text to binary form
    if (inet_pton(AF_INET, server_ip, &servaddr.sin_addr) <= 0) {
        perror("Invalid server IP address or address not supported");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    // 3. Send the filename first
    std::cout << "Attempting to send file: " << filename << " to " << server_ip << ":" << PORT << std::endl;
    sendto(sockfd, filename, strlen(filename), 0, (const struct sockaddr *)&servaddr, sizeof(servaddr));

    // 4. Open the file to be sent in binary read mode
    fp = fopen(filename, "rb");
    if (fp == nullptr) {
        perror("Failed to open file");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    // 5. Read file chunks and send them over UDP
    while (true) {
        // Read up to BUFFER_SIZE bytes from the file
        size_t bytesRead = fread(buffer, sizeof(char), BUFFER_SIZE, fp);
        
        if (bytesRead > 0) {
            // Send the read chunk
            sendto(sockfd, buffer, bytesRead, 0, (const struct sockaddr *)&servaddr, sizeof(servaddr));
        }

        // Check if we reached the end of the file or an error occurred
        if (bytesRead < BUFFER_SIZE) {
            if (feof(fp)) {
                // End of file reached successfully
                break;
            }
            if (ferror(fp)) {
                perror("Error reading file");
                fclose(fp);
                close(sockfd);
                exit(EXIT_FAILURE);
            }
        }
    }
    
    // 6. Send termination marker ("END")
    sendto(sockfd, "END", 3, 0, (const struct sockaddr *)&servaddr, sizeof(servaddr));
    std::cout << "File sent successfully and transfer marker ('END') transmitted." << std::endl;

    // 7. Cleanup
    if (fp) {
        fclose(fp);
    }
    close(sockfd);
    return 0;
}

