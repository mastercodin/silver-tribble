#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string>

using namespace std;

// Define the port and buffer size
#define PORT 8080
#define BUFFER_SIZE 1024

/**
 * @brief UDP Server program to receive a file from a client.
 */
int main() {
    int sockfd;
    struct sockaddr_in servaddr, cliaddr;
    socklen_t len;
    char buffer[BUFFER_SIZE];
    FILE *fp = nullptr;

    // 1. Create socket file descriptor
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        perror("socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Zero out the server address structure
    memset(&servaddr, 0, sizeof(servaddr));
    
    // Fill server information
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = INADDR_ANY;
    servaddr.sin_port = htons(PORT);

    // 2. Bind the socket with the server address
    if (bind(sockfd, (const struct sockaddr *)&servaddr, sizeof(servaddr)) < 0) {
        perror("bind failed");
        close(sockfd);
        exit(EXIT_FAILURE);
    }
    std::cout << "Server is running and waiting for file on port " << PORT << "..." << std::endl;

    len = sizeof(cliaddr);

    // 3. First, receive the filename
    // Note: UDP is connectionless. The 'cliaddr' will be populated with the sender's address.
    int n = recvfrom(sockfd, (char *)buffer, BUFFER_SIZE - 1, 0, (struct sockaddr *)&cliaddr, &len);

    if (n <= 0) {
        perror("Failed to receive filename");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    // Null-terminate the received filename string
    buffer[n] = '\0';
    
    // Construct the name for the received file
    std::string filename("received_");
    filename += buffer;
    
    // 4. Open a new file for writing the received content
    fp = fopen(filename.c_str(), "wb");
    if (fp == nullptr) {
        perror("Failed to create file");
        close(sockfd);
        exit(EXIT_FAILURE);
    }
    std::cout << "Receiving file: " << filename << std::endl;

    // 5. Start receiving file contents
    while (true) {
        n = recvfrom(sockfd, (char *)buffer, BUFFER_SIZE, 0, (struct sockaddr *)&cliaddr, &len);
        
        if (n < 0) {
            perror("recvfrom failed during file transfer");
            break;
        }

        // Check for the "END" marker from the client
        if (n == 3 && strncmp(buffer, "END", 3) == 0) {
            std::cout << "File transfer completed." << std::endl;
            break;
        }
        
        // Write the received data chunk to the file
        fwrite(buffer, sizeof(char), n, fp);
    }
    
    // 6. Cleanup
    if (fp) {
        fclose(fp);
    }
    close(sockfd);
    return 0;
}

