#include <iostream>
#include <iomanip>
#include <cstring>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <net/ethernet.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>

using namespace std;

/**
 * @brief Simple Raw Socket Packet Analyzer (Sniffer)
 * * This program opens a raw socket to capture all Ethernet frames (ETH_P_ALL) 
 * passing through an interface, and then parses and prints details from the 
 * Ethernet, IP, TCP, and UDP headers.
 * * NOTE: Running this program typically requires root/administrator privileges.
 */
int main() {
    int sock_raw;
    struct sockaddr saddr;
    socklen_t saddr_len = sizeof(saddr);
    
    // Allocate buffer to capture full Ethernet frames (up to 65536 bytes)
    unsigned char *buffer = new unsigned char[65536];

    // Create a raw socket to receive all packets (ETH_P_ALL)
    // AF_PACKET is specific to Linux and captures raw packets at the device driver level.
    sock_raw = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
    
    if (sock_raw < 0) {
        perror("Socket Error (Try running with sudo)");
        delete[] buffer;
        return 1;
    }
    
    cout << "Packet Analyzer started... (Press Ctrl+C to stop)" << endl;

    // Main loop to continuously capture and process packets
    while (true) {
        // Receive packet data
        int buflen = recvfrom(sock_raw, buffer, 65536, 0, &saddr, &saddr_len);
        
        if (buflen < 0) {
            perror("Recvfrom error");
            // Clean up and exit on error
            close(sock_raw);
            delete[] buffer;
            return 1;
        }

        // --- 1. Ethernet Header Parsing ---
        // The first header is the Ethernet header
        struct ethhdr *eth = (struct ethhdr *)buffer;
        
        cout << "\n=== Ethernet Header (Length: " << sizeof(struct ethhdr) << " Bytes) ===\n";
        
        // Print Source MAC Address in hexadecimal format
        cout << "Source MAC: ";
        for (int i = 0; i < 6; i++)
            cout << hex << setw(2) << setfill('0') << (int)eth->h_source[i] << (i == 5 ? "" : ":");
        
        // Print Destination MAC Address
        cout << "\nDestination MAC: ";
        for (int i = 0; i < 6; i++)
            cout << hex << setw(2) << setfill('0') << (int)eth->h_dest[i] << (i == 5 ? "" : ":");
            
        // Print Protocol (e.g., 0x0800 for IPv4)
        cout << "\nProtocol (Type): 0x" << hex << ntohs(eth->h_proto) << dec << endl;

        // --- 2. IP Header Parsing ---
        // Check if the protocol is IPv4 (0x0800)
        if (ntohs(eth->h_proto) == ETH_P_IP) {
            
            // IP header starts immediately after the Ethernet header
            struct iphdr *iph = (struct iphdr *)(buffer + sizeof(struct ethhdr));
            
            // Structures for converting IP addresses to readable strings
            struct sockaddr_in source, dest;
            source.sin_addr.s_addr = iph->saddr;
            dest.sin_addr.s_addr = iph->daddr;
            
            cout << "\n=== IP Header ===\n";
            cout << "Version: " << (unsigned int)iph->version << endl;
            // IHL is in 32-bit words, multiply by 4 to get bytes
            cout << "Header Length: " << (unsigned int)iph->ihl * 4 << " Bytes" << endl;
            cout << "Source IP: " << inet_ntoa(source.sin_addr) << endl;
            cout << "Destination IP: " << inet_ntoa(dest.sin_addr) << endl;
            // IP Protocol number (e.g., 6 for TCP, 17 for UDP)
            cout << "Protocol: " << (unsigned int)iph->protocol << endl;
            
            // --- 3. Transport Layer Header Parsing (TCP/UDP) ---
            unsigned int ip_header_len = iph->ihl * 4;
            
            if (iph->protocol == IPPROTO_TCP) {
                // TCP header starts after Ethernet and IP headers
                struct tcphdr *tcph = (struct tcphdr *)(buffer + sizeof(struct ethhdr) + ip_header_len);
                
                cout << "\n=== TCP Header ===\n";
                // Port numbers are 16-bit, so use ntohs()
                cout << "Source Port: " << ntohs(tcph->source) << endl;
                cout << "Destination Port: " << ntohs(tcph->dest) << endl;
                // Sequence and Ack numbers are 32-bit, so use ntohl()
                cout << "Sequence Number: " << ntohl(tcph->seq) << endl;
                cout << "Acknowledgement Number: " << ntohl(tcph->ack_seq) << endl;
                
            } else if (iph->protocol == IPPROTO_UDP) {
                // UDP header starts after Ethernet and IP headers
                struct udphdr *udph = (struct udphdr *)(buffer + sizeof(struct ethhdr) + ip_header_len);
                
                cout << "\n=== UDP Header ===\n";
                // Port numbers and Length are 16-bit, so use ntohs()
                cout << "Source Port: " << ntohs(udph->source) << endl;
                cout << "Destination Port: " << ntohs(udph->dest) << endl;
                cout << "Length: " << ntohs(udph->len) << " Bytes (Header + Data)" << endl;
            }
        }
        
        cout << "-----------------------------------------------\n";
    }

    // Cleanup (though this section is unreachable due to the infinite loop, it is good practice)
    close(sock_raw);
    delete[] buffer;
    return 0;
}

